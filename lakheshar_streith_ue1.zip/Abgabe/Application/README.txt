Um dei Applikation zu starten bitte "RUN.bat" anklicken.

CSV-Dateien mit den Kursdaten (bspw. wie jene von Yahoo) können im Ordner "csv" abgelegt werden
Die Benennung der sollte wie folgt aussehen:

Bsp.: Microsoft hat das Kürzel "msft" so soll auch die CSV-Datei welche die Kursdaten von Microsoft beinhalten msft.csv benannt werden.

Gespeicherte Hashtabellen werden im Ordner "saves" abgelegt und auch von dort wieder geladen.